mkdir ../t0
for photo in *.jpg ; do convert $photo -rotate 0 ../t0/t0$photo ; done
mkdir ../t5
for photo in *.jpg ; do convert $photo -rotate 5 ../t5/t5$photo ; done
mkdir ../t10
for photo in *.jpg ; do convert $photo -rotate 10 ../t10/t10$photo ; done
mkdir ../t15
for photo in *.jpg ; do convert $photo -rotate 15 ../t15/t15$photo ; done
mkdir ../t20
for photo in *.jpg ; do convert $photo -rotate 20 ../t20/t20$photo ; done
mkdir ../t25
for photo in *.jpg ; do convert $photo -rotate 25 ../t25/t25$photo ; done
mkdir ../t30
for photo in *.jpg ; do convert $photo -rotate 30 ../t30/t30$photo ; done
mkdir ../t35
for photo in *.jpg ; do convert $photo -rotate 35 ../t35/t35$photo ; done
mkdir ../t40
for photo in *.jpg ; do convert $photo -rotate 40 ../t40/t40$photo ; done
mkdir ../t45
for photo in *.jpg ; do convert $photo -rotate 45 ../t45/t45$photo ; done
mkdir ../t50
for photo in *.jpg ; do convert $photo -rotate 50 ../t50/t50$photo ; done
mkdir ../t55
for photo in *.jpg ; do convert $photo -rotate 55 ../t55/t55$photo ; done
mkdir ../t60
for photo in *.jpg ; do convert $photo -rotate 60 ../t60/t60$photo ; done
mkdir ../t65
for photo in *.jpg ; do convert $photo -rotate 65 ../t65/t65$photo ; done
mkdir ../t70
for photo in *.jpg ; do convert $photo -rotate 70 ../t70/t70$photo ; done
mkdir ../t75
for photo in *.jpg ; do convert $photo -rotate 75 ../t75/t75$photo ; done
mkdir ../t80
for photo in *.jpg ; do convert $photo -rotate 80 ../t80/t80$photo ; done
mkdir ../t85
for photo in *.jpg ; do convert $photo -rotate 85 ../t85/t85$photo ; done
mkdir ../t90
for photo in *.jpg ; do convert $photo -rotate 90 ../t90/t90$photo ; done
